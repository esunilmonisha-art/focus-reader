package com.example.focusreader

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var picker: Spinner
    private lateinit var minutes: EditText
    private var apps = listOf<Pair<String, String>>()   // label to package
    private var timer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(launcher, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setPadding(0, 32, 0, 8) }

        root.addView(TextView(this).apply { text = "Focus Reader"; textSize = 28f })
        root.addView(label("Reading app (the only app allowed)"))
        picker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, apps.map { it.first })
        }
        root.addView(picker)
        root.addView(label("Minutes"))
        minutes = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText("30") }
        root.addView(minutes)
        root.addView(Button(this).apply {
            text = "1. Turn on blocking permission"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply { text = "2. Start focus"; setOnClickListener { start() } })
        status = TextView(this).apply { textSize = 18f; setPadding(0, 48, 0, 0) }
        root.addView(status)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onPause() { super.onPause(); timer?.cancel() }

    private fun start() {
        if (!FocusService.isOn(this)) {
            Toast.makeText(this, "Turn on blocking permission first", Toast.LENGTH_LONG).show()
            return
        }
        val mins = minutes.text.toString().toLongOrNull() ?: 0L
        if (mins < 1 || apps.isEmpty()) return
        val pkg = apps[picker.selectedItemPosition].second
        getSharedPreferences("focus", MODE_PRIVATE).edit()
            .putLong("end", System.currentTimeMillis() + mins * 60000)
            .putString("allowed", pkg).apply()
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
        refresh()
    }

    private fun refresh() {
        timer?.cancel()
        val left = getSharedPreferences("focus", MODE_PRIVATE).getLong("end", 0) - System.currentTimeMillis()
        if (left <= 0) {
            status.text = if (FocusService.isOn(this)) "Ready. Blocking permission is on." else "Blocking permission is off."
            return
        }
        timer = object : CountDownTimer(left, 1000) {
            override fun onTick(ms: Long) { status.text = "Focus on: %d:%02d left".format(ms / 60000, ms / 1000 % 60) }
            override fun onFinish() { refresh() }
        }.start()
    }
}
