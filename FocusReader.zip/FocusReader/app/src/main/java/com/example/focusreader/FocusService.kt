package com.example.focusreader

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

class FocusService : AccessibilityService() {

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        val p = getSharedPreferences("focus", MODE_PRIVATE)
        if (System.currentTimeMillis() >= p.getLong("end", 0)) return   // no active session
        val allowed = p.getString("allowed", null) ?: return
        if (pkg == packageName || pkg == allowed || isSystem(pkg)) return
        // Any other app opened: send the user back to the reading app
        packageManager.getLaunchIntentForPackage(allowed)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(it)
        }
    }

    // Never block system UI, phone calls or the keyboard
    private fun isSystem(pkg: String): Boolean {
        if (pkg == "com.android.systemui" || pkg.contains("dialer") ||
            pkg.contains("incall") || pkg.contains("telecom")) return true
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == pkg }
    }

    override fun onInterrupt() {}

    companion object {
        fun isOn(c: Context): Boolean =
            Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?.contains(c.packageName) == true
    }
}
